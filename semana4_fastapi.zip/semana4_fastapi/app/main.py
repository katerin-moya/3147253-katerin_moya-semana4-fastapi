from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from . import models, schemas, crud
from .database import engine, Base, get_db

Base.metadata.create_all(bind=engine)

app = FastAPI(title="API Biblioteca")

# Usuarios
@app.post("/users/", response_model=schemas.User)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    return crud.create_user(db, user)

@app.get("/users/", response_model=list[schemas.User])
def read_users(db: Session = Depends(get_db)):
    return crud.get_users(db)


# Libros
@app.post("/books/", response_model=schemas.Book)
def create_book(book: schemas.BookCreate, owner_id: int, db: Session = Depends(get_db)):
    return crud.create_book(db, book, owner_id)

@app.get("/books/", response_model=list[schemas.Book])
def read_books(db: Session = Depends(get_db)):
    return crud.get_books(db)


# Préstamos
@app.post("/loans/", response_model=schemas.Loan)
def create_loan(loan: schemas.LoanCreate, db: Session = Depends(get_db)):
    return crud.create_loan(db, loan)

@app.get("/loans/", response_model=list[schemas.Loan])
def read_loans(db: Session = Depends(get_db)):
    return crud.get_loans(db)
