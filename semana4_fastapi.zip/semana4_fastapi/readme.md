# 📚 API Biblioteca - Semana 4 FastAPI

Este proyecto implementa una API de gestión de usuarios, libros y préstamos usando **FastAPI**, **SQLAlchemy** y **Pytest**.

## 🚀 Ejecutar la API
```bash
uvicorn app.main:app --reload
