def test_create_book(client):
    # Primero creamos un usuario para asignar dueño
    user = client.post("/users/", json={"name": "Bruno", "email": "bruno@example.com"}).json()
    response = client.post(f"/books/?owner_id={user['id']}", json={"title": "Libro A", "author": "Autor X"})
    assert response.status_code == 200
    assert response.json()["title"] == "Libro A"

def test_get_books(client):
    response = client.get("/books/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
