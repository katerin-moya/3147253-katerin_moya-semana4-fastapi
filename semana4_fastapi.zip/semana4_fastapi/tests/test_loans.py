def test_create_loan(client):
    # Creamos usuario y libro primero
    user = client.post("/users/", json={"name": "Laura", "email": "laura@example.com"}).json()
    book = client.post(f"/books/?owner_id={user['id']}", json={"title": "Libro B", "author": "Autor Y"}).json()

    response = client.post("/loans/", json={"user_id": user["id"], "book_id": book["id"]})
    assert response.status_code == 200
    assert response.json()["user_id"] == user["id"]

def test_get_loans(client):
    response = client.get("/loans/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
