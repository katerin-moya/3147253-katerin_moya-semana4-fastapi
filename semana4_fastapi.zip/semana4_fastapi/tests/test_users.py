def test_create_user(client):
    response = client.post("/users/", json={"name": "Katerin", "email": "kat@example.com"})
    assert response.status_code == 200
    assert response.json()["name"] == "Katerin"

def test_get_users(client):
    response = client.get("/users/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
